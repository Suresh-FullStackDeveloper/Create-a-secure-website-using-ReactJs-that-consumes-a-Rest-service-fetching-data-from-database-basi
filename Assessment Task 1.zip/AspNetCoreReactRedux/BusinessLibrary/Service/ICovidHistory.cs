﻿using System;
using System.Collections.Generic;
using System.Text;
using BusinessLibrary.Model;

namespace BusinessLibrary.Service
{
 public   class ICovidHistory
    {
       // Task<List<CovidHistoryModel>> GetCovidHistory();
    }
}
