﻿using BusinessLibrary.Model;
using DataAccessLibrary.EntityModels;
using Microsoft.EntityFrameworkCore;
using RestSharp;
//using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
namespace BusinessLibrary.Service
{
    public class CovidHistory
    {
        //public async Task<List<CovidHistoryModel>> GetCovidHistory()
        //{
        //    var client = new RestClient("https://covid-193.p.rapidapi.com/history?country=usa&day=2020-06-02");
        //    var request = new RestRequest(Method.GET);
        //    request.AddHeader("x-rapidapi-key", "9392d0e813msh9199d05b2b51c33p1392e1jsn6c28678f7243");
        //    request.AddHeader("x-rapidapi-host", "covid-193.p.rapidapi.com");
        //    IRestResponse response = client.Execute(request);

        //    return (CovidHistoryModel)response;
        //}
    }
}
