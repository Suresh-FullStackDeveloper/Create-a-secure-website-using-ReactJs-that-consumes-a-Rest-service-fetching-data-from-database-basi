﻿import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Growl } from 'primereact/growl';
import { actionCreators } from '../store/Contact';

class GetUAECovidHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            res: "",
            confirmedCases: 0,
            targetCountry: "",
            deathNumber: 0,
            targetProvince: "",
            userInput: "Azerbaijan"
        };
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.state.userInput !== prevState.userID) {

            fetch("https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats?country=" + this.state.userInput, {
                "method": "GET",
                "headers": {
                    "x-rapidapi-key": "2f66132eeemsh16e2dd05b2ecd59p1ab765jsnc1f549cafc64",
                    "x-rapidapi-host": "covid-19-coronavirus-statistics.p.rapidapi.com"
                }
            })
                .then(response => response.json()).then(data => {
                    this.setState({
                        res: data.data.lastChecked,
                        confirmedCases: data.data.covid19Stats[0].confirmed,
                        targetCountry: data.data.covid19Stats[0].country,
                        deathNumber: data.data.covid19Stats[0].deaths,
                        targetProvince: data.data.covid19Stats[0].province
                    })
                    console.log(data.data.covid19Stats[0].confirmed)
                })
                .catch(err => {
                    console.error(err);
                });
        }
    }

    handleChange = (target) => {
        this.setState({
            userInput: target
        });
    }
    render() {
        return (
            <div className="App">
                <button onClick={(target) => this.handleChange("UAE", target)}>United Arab Emirates</button>
                {/*<button onClick={(target) => this.handleChange("Russia", target)}>Russia</button>*/}
                {/*<button onClick={(target) => this.handleChange("Turkey", target)}>Turkey</button>*/}
      Last Updated:  {this.state.res}
                <br></br>
      Confirmed Cases:  {this.state.confirmedCases}
                <br></br>
      Country:  {this.state.targetCountry}
                <br></br>
      Number of Death:  {this.state.deathNumber}
                <br></br>
      Province:  {this.state.targetProvince}
            </div>
        );
    }
}
}