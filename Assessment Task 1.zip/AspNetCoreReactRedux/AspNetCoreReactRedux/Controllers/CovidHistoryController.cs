﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusinessLibrary.Model;
using System.Net.Http;
using Newtonsoft.Json;

namespace AspNetCoreReactRedux.Controllers
{
    public class CovidHistoryController : ControllerBase
    {


        //CovidHistoryDataAccessLayer objemployee = new CovidHistoryDataAccessLayer();

        // private readonly IContactService _contactService;
        [HttpGet]
        [Route("api/CovidSummary/Index")]
        public async Task<CovidHistoryModel> IndexAsync()
        {
           // var client = new RestClient("https://api.covid19api.com/summary");
            var client = new RestClient("https://covid-193.p.rapidapi.com/history?country=all&day=2020-06-02");
            //
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            var response = client.Execute(request);
            return (CovidHistoryModel)response;



    //        var client = new HttpClient();
    //        var request = new HttpRequestMessage
    //        {
    //            Method = HttpMethod.Get,
    //            RequestUri = new Uri("https://covid-193.p.rapidapi.com/history?country=usa&day=2020-06-02"),
    //            Headers =
    //{
    //    { "x-rapidapi-key", "9392d0e813msh9199d05b2b51c33p1392e1jsn6c28678f7243" },
    //    { "x-rapidapi-host", "covid-193.p.rapidapi.com" },
    //},
    //        };
    //        using (var response = await client.SendAsync(request))
    //        {
    //            response.EnsureSuccessStatusCode();
    //            var body = await response.Content.ReadAsStringAsync();
    //            Console.WriteLine(body);
    //            return (body);
    //        }
         
        }

        //[HttpGet]
        //[Route("api/Employee/Details/{id}")]
        //public TblEmployee Details(int id)
        //{
        //    //return objemployee.GetEmployeeData(id);
        //}

    }
}



